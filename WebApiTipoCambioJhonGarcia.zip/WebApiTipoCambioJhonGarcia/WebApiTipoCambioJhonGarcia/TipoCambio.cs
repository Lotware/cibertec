﻿namespace WebApiTipoCambioJhonGarcia
{
    public class TipoCambio
    {
        public int Id { get; set; }
        public double MontoOrigen { get; set; }
        public string MonedaOrigen { get; set; } = String.Empty;
        public string MonedaDestino { get;set; }=String.Empty;
        public double MontoDestino{ get; set; }
        public double ValorTipoCambio { get; set; }


    }
}
