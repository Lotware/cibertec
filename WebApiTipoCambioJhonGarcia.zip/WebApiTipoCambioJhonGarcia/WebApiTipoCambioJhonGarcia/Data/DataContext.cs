﻿using Microsoft.EntityFrameworkCore;

namespace WebApiTipoCambioJhonGarcia.Data
{
    public class DataContext: DbContext
    {
        public DataContext(DbContextOptions<DataContext> options): base(options) 
        {

        }

        public DbSet<TipoCambio> TipoCambio => Set<TipoCambio>(); 
    }
}
