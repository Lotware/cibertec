﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApiTipoCambioJhonGarcia.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TipoCambio",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    MontoOrigen = table.Column<double>(type: "REAL", nullable: false),
                    MonedaOrigen = table.Column<string>(type: "TEXT", nullable: false),
                    MonedaDestino = table.Column<string>(type: "TEXT", nullable: false),
                    MontoDestino = table.Column<double>(type: "REAL", nullable: false),
                    ValorTipoCambio = table.Column<double>(type: "REAL", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TipoCambio", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TipoCambio");
        }
    }
}
