﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiTipoCambioJhonGarcia.Data;

namespace WebApiTipoCambioJhonGarcia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TipoCambioController : ControllerBase
    {
        private readonly DataContext _context;

        public TipoCambioController(DataContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("New")]
        public async Task<ActionResult<List<TipoCambio>>> AddTipoCambio(TipoCambio tipoCambio)
        {
            if (tipoCambio.ValorTipoCambio > 0 && tipoCambio.MontoOrigen>0)
                {
                    tipoCambio.MonedaOrigen = "PEN";
                    tipoCambio.MonedaDestino = "USD";
                    tipoCambio.MontoDestino = tipoCambio.MontoOrigen /tipoCambio.ValorTipoCambio;


                    _context.TipoCambio.Add(tipoCambio);
                    await _context.SaveChangesAsync();

                    return Ok(await _context.TipoCambio.ToListAsync());
                }

            return BadRequest();
        }

        [HttpGet]
        [Route("List")]
        public async Task<ActionResult<List<TipoCambio>>> getAllTipoCambio()
        {
            return Ok(await _context.TipoCambio.ToListAsync());

        }

        [HttpPut]
        [Route("Update")]
        public async Task<ActionResult<List<TipoCambio>>> UpdateTipoCambio(TipoCambio tipoCambio)
        {
            if(tipoCambio.ValorTipoCambio>0)
            {

                var updateTipoCambio = await _context.TipoCambio.FirstOrDefaultAsync(e => e.Id == tipoCambio.Id);
                if(updateTipoCambio!=null)
                {
                    updateTipoCambio.ValorTipoCambio = tipoCambio.ValorTipoCambio;
                    updateTipoCambio.MontoDestino = tipoCambio.MontoOrigen / tipoCambio.ValorTipoCambio;

                    await _context.SaveChangesAsync();
                    return Ok(await _context.TipoCambio.ToListAsync());
                }

                return NotFound();

                


            }

            return BadRequest();
        }
    }
}

